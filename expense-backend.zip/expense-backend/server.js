const express = require('express');
const cors = require('cors');
const app = express();
const PORT = process.env.PORT || 3000;

// Enable CORS
app.use(cors({ origin: '*' }));
app.use(express.json());

// ============================================================
//  SUPER SIMPLE TEST ROUTE
// ============================================================

// ✅ This is the root route - should work immediately
app.get('/', (req, res) => {
  res.send('Hello! The server is running successfully! 🎉');
});

// ✅ Test endpoint
app.get('/test', (req, res) => {
  res.json({ message: 'Test endpoint works!', timestamp: new Date() });
});

// ✅ Get all data
app.get('/data', (req, res) => {
  res.json([]);
});

// ✅ Webhook endpoint
app.post('/webhook', (req, res) => {
  res.json({ success: true, received: req.body });
});

// ✅ Start server
app.listen(PORT, () => {
  console.log(`✅ Server running on port ${PORT}`);
  console.log(`📍 URL: http://localhost:${PORT}`);
  console.log(`📊 GET /data`);
  console.log(`📤 POST /webhook`);
});